<!DOCTYPE html>
<html>
<head>


<link href="style/user-stylesheet.css" rel="stylesheet" />
<link href="style/fonts/fonts.css" rel="stylesheet" />
<link href="style/payment.css" rel="stylesheet" />
<link rel="stylesheet" type="text/css" href="style/settings.css" media="screen" />
<link rel="stylesheet" type="text/css" href="style/style.css" media="screen" />
<link rel="stylesheet" type="text/css" href="style/style1.css" media="screen" />

<script type='text/javascript' src='js/jquery-1.8.1.js'></script>
<script type="text/javascript" src="js/PIE.js"></script>
<script type="text/javascript" src="js/js.js"></script>
<script type="text/javascript" src="js/jquery-ui.js"></script>

<script type="text/javascript" src="jquery.js"></script>
<script type="text/javascript" src="html5lightbox.js"></script>




<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta name="author" content="IMZWEB.com" />
<meta name="description" content="" />
<meta name="keywords" content="" />
</head>
<body>
        <!--header wrapper-->
        <div class="header-wrapper1">
            <!-- navbar -->
          <div class="navbar-wrapper">

      <div class="navbar">
            <a href="index.html" class="logo"><img src="images/logo.png" /></a>
                <div class="navbar">
            
              <ul class="r nav-links">
                <p style="margin-top:40px;color:#efbb1e;float: right;">Call us : +91 8220000769</p>
</ul>

            </div>
              <ul class="r nav-links">
                <li><a href="index1.php" >home</a></li>
                            <li><a href="payment1.php">order now</a></li>
                            <li><a href="contact.php">contact us</a></li>
                        </ul>

            </div>

    
                <!-- slider -->


            <!-- slider End -->
          </div>
             <!-- end navbar -->

      </div>


<h1 class='payment'>Contact Us</h1>


<div style="margin:150px 300px;">

    

      <h1 style="text-decoration: underline;color:red;">Address :</h1><h3 style="color:green;""><p>Toon Explainers</p><br><p>No.3, Raja Street, Kallimadai,Trichy Road,</p></br><p> Singanallur,Tamilnadu, Coimbatore - 641005</p><br>Mobile: +91 8220000769 , Email : info@toonexplainers.com</h3>




    </h3>






</div>
        <div id="footer">
  <div id="innerfooter">
    <h2 style="text-decoration:underline;padding:2px;">Reach us</h2>

  <p>
  Toon ExplainersNo.3, Raja Street, Kallimadai,Trichy Road, Singanallur,Tamilnadu, Coimbatore - 641005 <br>Mobile: +91 8220000769 , Email : info@toonexplainers.com
  </p>
  <ul class="social">
<li>
<a href="https://www.facebook.com" target=_blank><img src="images/Top-head-icon-1.png" class="img-responsive hvr-pop"></a>
</li>
<li>
<a href="https://twitter.com/" target=_blank><img src="images/Top-head-icon-2.png" class="img-responsive hvr-pop"></a>
</li>
<li>
<a href="https://plus.google.com/" target=_blank><img src="images/Top-head-icon-3.png" class="img-responsive hvr-pop"></a>
</li>
<li>
<a href="https://www.youtube.com/channel/" target=_blank><img src="images/yt.png" class="img-responsive hvr-pop" style="width:25px;"></a>
</li>
</ul>

  </div>
  <br> <br>
        <div class="copyright">
            <p>All rights reserved to <a href="#">ToonExplainers</a></a></p>
         </div>
</div>
</body>
</html>