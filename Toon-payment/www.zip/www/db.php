<?php
$con = mysql_connect('localhost','madurama_joyson','joyson$81');
mysql_select_db('madurama_tooninner2');

?>